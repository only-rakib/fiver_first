from django.apps import AppConfig


class MyappsConfig(AppConfig):
    name = 'myapps'
